# Jio TV Plus — Android starter project

This is a **native Android source project** intended as a starting point for a player that can run on Android phones, Android TV, and compatible Amazon Fire TV devices.

## Included
- Android app project using Kotlin
- Xtream Codes-style login fields (server URL, username, password)
- M3U URL parsing
- Basic channel list, grouping, search
- Media3/ExoPlayer playback for supported stream formats
- Launcher and Leanback entry points, touch and D-pad focus support

## Build the APK
1. Install Android Studio (current stable) and its Android SDK.
2. Open the `Jio_TV_Plus_Android_Project` folder in Android Studio.
3. Allow Gradle sync and install any prompted SDK components (compile SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output path, typically `app/build/outputs/apk/debug/app-debug.apk`.
6. Install that APK on your own Android phone for testing. Fire TV may require allowing installation from the chosen installer; only install apps you trust.

## Current limitations / testing still required
- This is source code, **not a compiled or tested APK**. Build in Android Studio and test on real devices before distribution.
- Provider APIs vary. The Xtream API implementation currently loads live streams and VOD movies; series episode browsing, EPG, favorites, saved profiles, and playback fallback are not implemented yet.
- Stream extensions and codecs differ by provider; the current live URL uses `.m3u8` and VOD uses `.mp4`. A server may require a different supported format.
- Some providers require HTTPS or special headers, or deny access; no player can guarantee every IPTV server will work.
- The app does not persist credentials intentionally. Avoid sharing screenshots or logs containing subscription credentials.
- Use only IPTV subscriptions and content you are authorized to access.
- **Jio TV Plus is an independent player concept, not an official Jio app and not affiliated with Jio.** Confirm branding/trademark rights before public distribution.

## Security note
This starter enables cleartext HTTP to support legacy IPTV servers. Prefer HTTPS whenever the provider supports it. Do not use credentials you do not have permission to use.
