package com.premiumentertainment.jiotvplus

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.InputType
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

data class Channel(val name: String, val group: String, val url: String, val kind: String = "Live TV")

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(12, 11, 18)
    private val panel = Color.rgb(27, 24, 38)
    private val accent = Color.rgb(225, 61, 117)
    private val pale = Color.rgb(247, 243, 251)
    private val muted = Color.rgb(170, 163, 183)
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private var channels: List<Channel> = emptyList()
    private var mode = "xtream"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("Jio TV Plus", 28, pale, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        root.addView(text("Universal IPTV Player • Mobile / Android TV / Fire TV", 13, muted))
        root.addView(text("Independent player concept — not an official Jio app.", 11, muted).apply {
            setPadding(0, dp(2), 0, dp(16))
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val xtream = button("Xtream Codes")
        val m3u = button("M3U Playlist")
        tabs.addView(xtream, weightParams())
        tabs.addView(m3u, weightParams())
        root.addView(tabs)
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(fields)
        val server = edit("Server URL", "http://server.example:8080", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val username = edit("Username", "Enter username")
        val password = edit("Password", "Enter password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val playlist = edit("M3U playlist URL", "https://example.com/playlist.m3u", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        fun setMode(next: String) {
            mode = next
            fields.removeAllViews()
            if (next == "xtream") {
                fields.addView(fieldLabel("Server URL")); fields.addView(server)
                fields.addView(fieldLabel("Username")); fields.addView(username)
                fields.addView(fieldLabel("Password")); fields.addView(password)
            } else {
                fields.addView(fieldLabel("M3U playlist URL")); fields.addView(playlist)
            }
            fields.addView(button("Connect playlist") {
                try {
                    hideKeyboard()
                    if (mode == "xtream") {
                        connectXtream(server.text.toString().trim(), username.text.toString().trim(), password.text.toString())
                    } else {
                        connectM3u(playlist.text.toString().trim())
                    }
                } catch (e: Exception) {
                    setStatus("Could not start connection: ${e.message ?: "please check the details"}", true)
                }
            })
        }
        xtream.setOnClickListener { setMode("xtream") }
        m3u.setOnClickListener { setMode("m3u") }
        setMode("xtream")

        status = text("Enter your authorized IPTV details to connect.", 12, muted)
        status.setPadding(dp(10), dp(10), dp(10), dp(10))
        status.setBackgroundColor(panel)
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(16) })

        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(8) }
        }
        root.addView(playerView)
        root.addView(text("Channels & content", 20, pale, true).apply {
            setPadding(0, dp(18), 0, dp(8))
        })
        val search = EditText(this).apply {
            hint = "Search channels"
            setTextColor(pale); setHintTextColor(muted); textSize = 15f
            setSingleLine(true); setPadding(dp(12))
            setBackgroundColor(panel)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        search.addTextChangedListener(SimpleTextWatcher { renderChannels(it) })
    }

    private fun connectXtream(baseRaw: String, user: String, pass: String) {
        if (baseRaw.isBlank() || user.isBlank() || pass.isBlank()) {
            setStatus("Enter server URL, username and password.", true); return
        }
        if (!baseRaw.startsWith("http://") && !baseRaw.startsWith("https://")) {
            setStatus("Server URL must start with http:// or https://", true); return
        }
        setStatus("Connecting to server…")
        executor.execute {
            try {
                val base = baseRaw.trimEnd('/')
                val api = "$base/player_api.php?username=${enc(user)}&password=${enc(pass)}"
                val auth = JSONObject(request(api))
                if (auth.optJSONObject("user_info")?.optString("auth") == "0") error("Server rejected these login details.")
                // Load live channels first. Some providers return very large VOD catalogues;
                // loading them all at startup can exhaust memory on phones.
                val live = getJsonArray("$api&action=get_live_streams")
                val result = ArrayList<Channel>()
                addXtream(result, live, base, user, pass, "Live TV", "m3u8")
                if (result.isEmpty()) error("Login worked, but the server returned no live channels. Check provider API access.")
                runOnUiThread {
                    channels = result
                    renderChannels("")
                    setStatus("Connected: ${result.size} live channels loaded. Showing up to 120 at once.")
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Connection failed: ${e.message ?: "check server and network"}", true) }
            }
        }
    }

    private fun addXtream(out: MutableList<Channel>, arr: JSONArray, base: String, user: String, pass: String, kind: String, ext: String) {
        // Avoid building an unbounded in-memory list if a provider returns an enormous catalogue.
        val limit = minOf(arr.length(), 10000)
        for (i in 0 until limit) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("stream_id")
            if (id.isBlank() || id == "null") continue
            val name = o.optString("name", "$kind item")
            val group = o.optString("category_name", kind)
            val url = "$base/${if (kind == "Live TV") "live" else "movie"}/${enc(user)}/${enc(pass)}/$id.$ext"
            out.add(Channel(name, group, url, kind))
        }
    }

    private fun connectM3u(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            setStatus("Enter a valid HTTP(S) M3U playlist URL.", true); return
        }
        setStatus("Loading playlist…")
        executor.execute {
            try {
                val data = request(url)
                val parsed = parseM3u(data)
                if (parsed.isEmpty()) error("No valid HTTP(S) stream entries found.")
                runOnUiThread {
                    channels = parsed
                    renderChannels("")
                    setStatus("Playlist loaded: ${parsed.size} channels.")
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Playlist failed: ${e.message ?: "check URL/network"}", true) }
            }
        }
    }

    private fun parseM3u(data: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name = "Channel"
        var group = "Other"
        var kind = "Live TV"
        // Parse at most 10,000 entries to protect lower-memory Android devices.
        for (raw in data.removePrefix("\uFEFF").lineSequence()) {
            if (result.size >= 10000) break
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfter(',', "Channel").trim().ifBlank { "Channel" }
                group = Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1) ?: "Other"
                kind = if (group.contains("movie", true)) "Movies" else if (group.contains("series", true)) "Series" else "Live TV"
            } else if (line.startsWith("http://") || line.startsWith("https://")) {
                result.add(Channel(name, group, line, kind))
                name = "Channel"; group = "Other"; kind = "Live TV"
            }
        }
        return result
    }

    private fun getJsonArray(url: String): JSONArray = try { JSONArray(request(url)) } catch (_: Exception) { JSONArray() }

    private fun request(address: String): String {
        val conn = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 18000
            setRequestProperty("User-Agent", "JioTVPlus/0.1 Android")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            if (stream == null) error("HTTP $code returned no response body")
            val body = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                var total = 0
                while (true) {
                    val count = reader.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > 12 * 1024 * 1024) error("Playlist/API response is too large (over 12 MB). Ask provider for a smaller playlist.")
                    out.append(buffer, 0, count)
                }
                out.toString()
            }
            if (code !in 200..299) error("HTTP $code")
            return body
        } finally { conn.disconnect() }
    }

    private fun renderChannels(query: String) {
        list.removeAllViews()
        val filtered = channels.asSequence()
            .filter { it.name.contains(query, true) || it.group.contains(query, true) }
            .take(120)
            .toList()
        if (filtered.isEmpty()) {
            list.addView(text(if (channels.isEmpty()) "Connect a playlist to load channels." else "No matching channels.", 13, muted)
                .apply { setPadding(dp(8), dp(16), dp(8), dp(16)) })
            return
        }
        if (channels.size > 120 && query.isBlank()) {
            list.addView(text("Showing first 120 of ${channels.size} channels. Use Search channels to find others.", 12, muted)
                .apply { setPadding(dp(8), dp(10), dp(8), dp(10)) })
        }
        var lastGroup = ""
        filtered.forEach { channel ->
            if (channel.group != lastGroup) {
                lastGroup = channel.group
                list.addView(text(channel.group, 14, Color.rgb(229, 148, 207), true).apply {
                    setPadding(dp(4), dp(14), dp(4), dp(4))
                })
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12))
                setBackgroundColor(panel)
                isFocusable = true
                isClickable = true
            }
            row.addView(text(channel.name, 15, pale, true))
            row.addView(text(channel.kind, 11, muted))
            row.setOnClickListener { play(channel) }
            row.setOnFocusChangeListener { v, focused -> v.setBackgroundColor(if (focused) Color.rgb(67, 40, 69) else panel) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
    }

    private fun play(channel: Channel) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build()
                playerView.player = player
            }
            player?.setMediaItem(MediaItem.fromUri(channel.url))
            player?.prepare()
            player?.playWhenReady = true
            setStatus("Playing: ${channel.name}")
        } catch (e: Exception) {
            setStatus("Could not start playback: ${e.message ?: "unsupported stream"}", true)
        }
    }

    private fun setStatus(message: String, error: Boolean = false) {
        if (!::status.isInitialized || isFinishing || isDestroyed) return
        // Always update Android views on the main thread, even if a caller is a worker.
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            runOnUiThread { setStatus(message, error) }
            return
        }
        status.text = message
        status.setTextColor(if (error) Color.rgb(255, 145, 165) else muted)
    }

    private fun fieldLabel(label: String) = text(label, 12, muted).apply {
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun edit(label: String, hintText: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
        contentDescription = label
        hint = hintText; setTextColor(pale); setHintTextColor(muted); textSize = 14f
        inputType = type; setSingleLine(true); setPadding(dp(12))
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(-1, dp(48))
    }

    private fun edit(label: String, hintText: String): EditText = edit(label, hintText, InputType.TYPE_CLASS_TEXT)

    private fun button(label: String, action: (() -> Unit)? = null): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
        setPadding(dp(8))
        if (action != null) setOnClickListener { action() }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(root.windowToken, 0)
    }

    override fun onDestroy() {
        player?.release(); player = null
        executor.shutdownNow()
        super.onDestroy()
    }
}
